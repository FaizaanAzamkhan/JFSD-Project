package com.example.projectdemo;

public interface PeopleDAO {

	public void savePeople(People people);
}
