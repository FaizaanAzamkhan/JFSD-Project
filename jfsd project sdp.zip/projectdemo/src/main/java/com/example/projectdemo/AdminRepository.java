package com.example.projectdemo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminRepository extends JpaRepository<AdminDetails,Long>{

}
