package com.example.projectdemo;

public interface AdminDAO {

	public void saveAdmin(AdminDetails admindetails);
}
