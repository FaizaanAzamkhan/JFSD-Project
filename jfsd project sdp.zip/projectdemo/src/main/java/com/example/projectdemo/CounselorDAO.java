package com.example.projectdemo;

public interface CounselorDAO {

	public void saveCounselor(Counselor counselor);
}
