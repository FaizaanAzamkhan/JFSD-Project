package com.example.projectdemo;



public interface StudentDAO {
	public void insertStudent(Student st);
	  
}
